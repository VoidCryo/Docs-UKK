```mermaid

graph TB
    Teacher{{Teacher}}

    subgraph Sub["Web Pendaftaran Ekstrakulikuler"]
        SignIn(Login)
        Dashboard(Dashboard)
        Notifikasi(Notifikasi)
        Jadwal(Pembuatan Jadwal Ekstrakulikuler)
        PenerimaanAnggota(Penerimaan Anggota Baru)
        EditProfil(Edit Profil)
        VerifikasiPassword(Verifikasi Password)

        SignIn -.->|include| VerifikasiPassword
        SignIn -.->|include| Dashboard
        
        Dashboard -.->|include| Notifikasi

        Jadwal -.->|extend| Dashboard

        PenerimaanAnggota -.->|extend| Dashboard

        EditProfil -.->|extend| Dashboard

    end

    Teacher --> SignIn

```
