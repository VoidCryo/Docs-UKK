```mermaid

graph TB
    Student{{Student}}

    subgraph Sub["Web Pendaftaran Ekstrakulikuler"]
        SignUp(Registrasi)
        SignIn(Login)
        PembuatanProfil(Pembuatan Profil)
        Dashboard(Dashboard)
        EditProfil(Edit Profil)
        Notifikasi(Notifikasi)
        Jadwal(Jadwal Ekstrakulikuler)
        Ekstrakulikuler(Ekstrakulikuler)
        PendaftaranEkstrakulikuler(Pendaftaran Ekstrakulikuler)
        ProfilPembina(Profil Pembina)
        VerifikasiPassword(Verifikasi Password)

        SignIn -.->|include| VerifikasiPassword
        SignIn -.->|include| Dashboard

        SignUp -.->|include| PembuatanProfil
        
        Dashboard -.->|include| Notifikasi
        Dashboard -.->|include| Jadwal
        
        Ekstrakulikuler -.->|include| ProfilPembina

        PendaftaranEkstrakulikuler -.->|extend| Ekstrakulikuler

        EditProfil -.->|extend| Dashboard

    end

    Student --> SignUp
    Student --> SignIn

```
